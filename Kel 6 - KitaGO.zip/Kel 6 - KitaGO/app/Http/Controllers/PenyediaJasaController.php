<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\PenyediaJasa;
use App\Models\Customer;
use App\Models\Penginapan;
use App\Models\Wisata;

class PenyediaJasaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function makePJ($id)
    {
        $data = Customer::find($id);
        $nData = new PenyediaJasa;
            $nData->id = $data->id;
            $nData->usernameP = $data->usernameC;
            $nData->passwordP = $data->passwordC;
        $nData->save();
        return redirect('/kgweb');
    }

    public function index()
    {
        $data = Paket::get();
        return view('kgweb.paket', ['list' => $data]);
    }

    public function inputPenginapan()
    {
        $data = new Penginapan;
            $data->id = $request->id;
            $data->namaPenginapan = $request->namaPenginapan;
            $data->hargaP = $request->hargaP;
        $data->save();
        return redirect('/kgweb/paket');
    }

    public function inputWisata()
    {
        $data = new Wisata;
            $data->id = $request->id;
            $data->namaWisata = $request->namaWisata;
            $data->hargaW = $request->hargaW;
        $data->save();
        return redirect('/kgweb/paket');
    }

    public function inputPaket()
    {
        $data = new Penginapan;
            $data->id = $request->id;
            $data->namaPenginapan = $request->namaPenginapan;
            $data->hargaP = $request->hargaP;
        $data->save();
        return redirect('/kgweb/paket');
    }

    public function editPenginapan($id)
    {
        return view('kgweb.PJform', [
            'title' => 'Edit Penginapan',
            'method' => 'PUT',
            'action' => "kgweb/$id",
            'data' => Penginapan::find($id)
        ]);  
    }

    public function editWisata($id)
    {
        return view('kgweb.PJform', [
            'title' => 'Edit Wisata',
            'method' => 'PUT',
            'action' => "kgweb/$id",
            'data' => Wisata::find($id)
        ]);  
    }

    public function updatePenginapan(Request $request, $id)
    {
        $data = Penginapan::find($id);
            $data->id = $request->id;
            $data->namaPenginapan = $request->namaPenginapan;
            $data->hargaP = $request->hargaP;
        $data->save();
        return redirect('/kgweb/paket');
    }

    public function updateWisata(Request $request, $id)
    {
        $data = Wisata::find($id);
            $data->id = $request->id;
            $data->namaWisata = $request->namaWisata;
            $data->hargaW = $request->hargaW;
        $data->save();
        return redirect('/kgweb/paket');
    }
}
